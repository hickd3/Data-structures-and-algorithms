/*
file name:      LandscapeTests.java
Authors:        Max Bender & Naser Al Madi
last modified:  9/18/2022

How to run:     java -ea LandscapeTests
*/


import java.util.ArrayList;

public class LandscapeTests {

    public static void landscapeTests() {

        // case 1: testing Landscape(int, int)
        {
            // set up
            Landscape l1 = new Landscape(2, 4);
            Landscape l2 = new Landscape(10, 10);

            // verify
            System.out.println(l1);
            System.out.println("\n");
            System.out.println(l2);

            // test
            assert l1 != null : "Error in Landscape::Landscape(int, int)";
            assert l2 != null : "Error in Landscape::Landscape(int, int)";
        }

        // case 2: testing reset()
        {
            // set up
            Landscape l1 = new Landscape(3, 3);
            l1.getCell(1, 1).setAlive(true);
            System.out.println("Before reset:");
            System.out.println(l1);

            // verify
            l1.reset();
            System.out.println("After reset:");
            System.out.println(l1);

            // test
            boolean allDead = true;
            for (int i = 0; i < l1.getRows(); i++) {
                for (int j = 0; j < l1.getColumns(); j++) {
                    if (l1.getCell(i, j).getAlive()) {
                        allDead = false;
                        break;
                    }
                }
            }
            assert allDead : "Error in Landscape::reset()";
        }
        }

        // case 3: testing getRows()
        {
            // set up
            Landscape l1 = new Landscape(4, 5);

            // verify
            assert l1.getRows() == 4 : "Error in Landscape::getRows()";
            // test

        }

        // case 4: testing getCols()
        {
            // set up
            Landscape l1 = new Landscape(4, 5);

            // verify
            assert l1.getColumns() == 5 : "Error in Landscape: getColumns()";

            // test

        }

        // case 5: testing getCell(int, int)
        {
            // set up
            Landscape l1 = new Landscape(4, 5);

            // verify
            assert l1.getCell(1, 2) != null : "Error in Landscape: getCell(int, int)";
        }

            // test

        

        // case 6: testing getNeighbors()
        {
            // set up
            Landscape l1 = new Landscape(3, 3);
            l1.getCell(0, 0).setAlive(true);
            l1.getCell(0, 1).setAlive(true);
            l1.getCell(1, 0).setAlive(true);
            l1.getCell(1, 1).setAlive(true);
            System.out.println(l1);



            // verify
            ArrayList<Cell> neighbors = l1.getNeighbors(0, 0);
            assert neighbors.size() == 3 : "Error in Landscape: getNeighbors()";

            // test
            boolean allAlive = true;
            for (Cell neighbor : neighbors) {
                if (!neighbor.getAlive()) {
                    allAlive = false;
                    break;
                }
            }
            assert allAlive : "Error in Landscape::getNeighbors()";
        }

        // case 7: testing advance()
        {
            // set up
            Landscape l1 = new Landscape(4, 4);
            l1.getCell(1, 1).setAlive(true);
            l1.getCell(1, 2).setAlive(true);
            l1.getCell(2, 1).setAlive(true);
            l1.getCell(2, 2).setAlive(true);
            System.out.println("Before advance:");
            System.out.println(l1);

            // verify
            l1.advance();
            System.out.println("After advance:");
            System.out.println(l1);
        


            // test
            assert !l1.getCell(1, 1).getAlive() : "Error in Landscape::advance()";
            assert !l1.getCell(1, 2).getAlive() : "Error in Landscape::advance()";
            assert !l1.getCell(2, 1).getAlive() : "Error in Landscape::advance()";
            assert !l1.getCell(2, 2).getAlive() : "Error in Landscape::advance()";
            assert l1.getCell(1, 3).getAlive() : "Error in Landscape::advance()";
            assert l1.getCell(2, 3).getAlive() : "Error in Landscape::advance()";
            assert l1.getCell(3, 1).getAlive() : "Error in Landscape::advance()";
            assert l1.getCell(3, 2).getAlive() : "Error in Landscape::advance()";
            assert l1.getCell(3, 3).getAlive() : "Error in Landscape::advance()";
        }

        

    


    public static void main(String[] args) {

        landscapeTests();
    }
}
