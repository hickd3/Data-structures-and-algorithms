/*
 * File: Landscape.java
 * Author: Dean Hickman
 * Date: May 2023
 * CS231 A
 * Project 02
 * 
*/



import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

public class Landscape{
    //underlying grid for Conway's game
    private Cell[][] landscape;
    private int rows; 
    private int columns;
    private int i;
    private int j;
    private Cell[][] grid;
    //set up a grid with row and columns of specified values and allocates the Cell object to each Grid location
    public Landscape(int rows, int columns){
        this.rows = rows;
        this.columns = columns;
        this.grid = new Cell[rows][columns];
       landscape = new Cell[rows][columns];
        for (i=0; i < rows; i++){
            for (j=0; j < columns; j++){
             Cell cell = new Cell(false);
             landscape[i][j] = cell;
             cell.setAlive(false);   
            }
        }
    }
    //same as the above method however each sell starts with a chance of being alive
    public Landscape(int rows, int columns, double chance){
        this.landscape= new Cell[rows][columns];
        for (int i=0; i < rows; i++){
            for (int j =0; j < columns; j++){
                if (Math.random() <= chance){
                    this.landscape[i][j] = new Cell(true);
                }
                else{
                    this.landscape[i][j] = new Cell(false);
                }
            }
        }
    }
    //recreates the grid
    public void reset(){
        for (i=0; i < rows; i++){
            for (j=0; j < columns; j++){
             Cell cell = new Cell(false);
             landscape[i][j] = cell;
             cell.setAlive(false);   
            }
        }
    }
    public void setPattern(int x, int y) {
        // Set a specific pattern of cell activity
        // For example, set a single cell at coordinates (x, y) to be alive
        grid[x][y].setAlive(true);
    }

    //returns the number of rows in the Landscape
    public int getRows(){
        return this.rows;  
    }
    //returns the number of columns in the Landscape
	public int getColumns(){	
		return this.columns;													// return the number of columns
	}
    //returns reference to cell at (rows, columns)
    public Cell getCell(int rows, int columns){
        return this.landscape[rows][columns];
    }
    //convert landscape into text-based string representation
	public String toString(){
        String y = "";
        for (i=0; i < rows; i++){
            for (j=0; j < columns; j++){
                y += "" + landscape[i][j];
            }
            y+= "\n"; 
        }
        return y;
    }
    // Return an ArrayList to the neighbors of the Cell at location (rows, colums). But not the cell at that location.
    public ArrayList<Cell> getNeighbors( int rows, int columns){
        ArrayList<Cell> neighbors = new ArrayList<>();

        // Define the range of rows and columns to iterate over
        int startRow = Math.max(0, rows - 1);
        int endRow = Math.min(rows - 1, rows + 1);
        int startColumns = Math.max(0, columns - 1);
        int endColumns = Math.min(columns - 1, columns + 1);

        // Iterate over the neighboring cells
        for (int i = startRow; i <= endRow; i++) {
            for (int j = startColumns; j <= endColumns; j++) {
                if (i != rows || j != columns) { // Exclude the cell at (row, col)
                    neighbors.add(landscape[i][j]);
                }
            }
        }
        return neighbors;  
    }
    public void draw(Graphics g, int gridScale) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                Cell cell = landscape[i][j];
                int x = j * gridScale;
                int y = i * gridScale;
                if (cell.getAlive()) {
                    g.setColor(Color.WHITE);
                } else {
                    g.setColor(Color.BLACK);
                }
                g.fillRect(x, y, gridScale, gridScale);
            }
        }
    }
//advance the cells forward one generation
public void advance(){
    Cell[][] newGrid = new Cell[rows][columns];
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            boolean condition = landscape[i][j].getAlive();
            Cell newCell = new Cell(condition);
            newCell.updateState(getNeighbors(i, j));
            newGrid[i][j] = newCell;
        }
    }
    landscape = newGrid;
}
//main method
public static void main(String[] args){
 Landscape landscape = new Landscape(10, 10,0.8);
 landscape.getCell(2, 3).setAlive(true);
landscape.getCell(4, 6).setAlive(true);
 System.out.println("Landscape: ");
 System.out.println(landscape.toString());

 System.out.println("number of rows: " + landscape.getRows());
 System.out.println("number of columns: " + landscape.getColumns());
 System.out.println("get cell at (2, 3): " + landscape.getCell(2,3));
       
System.out.println("neighbors case A: " + landscape.getNeighbors(2,3));
System.out.println("neighbors case B: " + landscape.getNeighbors(6,3));
System.out.println("neighbors case C: " + landscape.getNeighbors(4,6));

      
System.out.println("Landscape reset: ");
landscape.reset();
System.out.println(landscape.toString());

}
public void pattern() {
}


}