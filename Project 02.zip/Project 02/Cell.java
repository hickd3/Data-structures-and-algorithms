/*
 * File: Cell.java
 * Author: Dean Hickman
 * Date: May 2023
 * CS231 A
 * Project 02
 * 
*/

import java.util.ArrayList;


 public class Cell{
    private boolean alive;

    //constructor method
    public Cell(){
        alive = false; // default is dead
    }
    // boolean specifies if the cell is alive (true) or dead (false)
    public Cell(boolean alive){
        if(alive){
            this.alive = true;
        }
        else{
            this.alive = false;

        }
    }
    // Is the cell dead or alive
    public boolean getAlive(){
        return this.alive;
    }
    // sets the state of the cell
    public void setAlive(boolean alive){
        if(alive){
            this.alive = true;
        }
        if (!alive){
            this.alive = false;
        }
    }
    // returns a string that tells whether the cell is alive (1) or dead (0)
    @Override
public String toString() {
    if (alive) {
        return "O";
    } else {
        return ".";
    }
}
    //updates whether or not the cell is alive in the next time step, given its neighbors in the current time step
    public void updateState( ArrayList<Cell> neighbors ){
        ArrayList<Cell> liveNeighbors = new ArrayList<Cell>();
        for (int i =0; i < neighbors.size(); i++) {
            if (neighbors.get(i).getAlive()) {
                liveNeighbors.add(neighbors.get(i));
            }
        }
        if(alive = true){
           if ((liveNeighbors.size() < 2 || liveNeighbors.size() > 3)) {
            alive = true;   
        }else{
            alive = false;
        }
      
        } else if (!alive && liveNeighbors.size() == 3) {
            alive = true;
        }
    }

// main method
public static void main(String[] args){
    Cell cell = new Cell();
    cell.getAlive();
    System.out.println(cell.toString());
    cell.setAlive(true);
    System.out.println(cell.toString());
}
 }



