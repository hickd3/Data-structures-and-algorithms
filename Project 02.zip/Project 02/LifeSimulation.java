/*
 * File: LifeSimulation.java
 * Author: Dean Hickman
 * Date: May 2023
 * CS231 A
 * Project 02
 * 
*/
import java.awt.Color;
import java.awt.Graphics;
import java.util.Scanner;

public class LifeSimulation {
    //main method
    public static void main(String[] args) throws InterruptedException {
        //set up scanner and take in the users time value as an arg
        Scanner inputTime = new Scanner(System.in);
        System.out.print("Enter the number of milliseconds you would like the program to pause for between frames: ");
        int time = inputTime.nextInt();
        inputTime.close();
//allow the user to customize the simulation
        int gridSize = 100;
        int steps = 100;
        if (args.length >= 1) {
            gridSize = Integer.parseInt(args[0]);
        }
        if (args.length >= 2) {
            steps = Integer.parseInt(args[1]);
        }
//set up landscape in the display
        Landscape landscape = new Landscape(gridSize, gridSize, 0.3);
        LandscapeDisplay display = new LandscapeDisplay(landscape, landscape.getRows(), landscape.getColumns(), steps);
        display.setCellSize(8);
        display.setBackground(Color.WHITE);
//iteration block updates 100 times
        for (int i =0; i < steps; i++) {
            landscape.advance();
            display.draw(landscape);
            display.repaint();
            Thread.sleep(time);
        }
    }
}
