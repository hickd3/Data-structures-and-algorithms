/*
 * File: Grid.java
 * Author: Dean Hickman
 * Date: May 2023
 * CS231 A
 * Lab 02
 * 
 */
import java.util.Random;

public class Grid {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("To use this class, Grid, follow format: java Grid [arg 1] [arg 2] [args..]");
        } else {
                for (String x : args) {
                System.out.println(x);
            }
        }
        for (int i = 0; i < args.length; i++) {
            System.out.println(args[i]);
            
        }
        int[][] arr = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

        System.out.println("Original array:");
        printArray(arr);

        int[][] rotatedArr = rotate(arr);
        System.out.println("Rotated array:");
        printArray(rotatedArr);
        
        String[][] grid = new String[3][];
        Random random = new Random();
        for (int i = 0; i < 3; i++) {
            grid[i] = new String[i + 3];
            for (int j = 0; j < grid[i].length; j++) {
                char y = (char) (random.nextInt(26) + 'A');
                grid[i][j] = Character.toString(y);
            }
        }
    }


    public static void printArray(int[][] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static boolean gridEquals(int[][] arr1, int[][] arr2) {
        if (arr1.length != arr2.length || arr1[0].length != arr2[0].length) {
            return false;
        }
        for (int i = 0; i < arr1.length; i++) {
            for (int j = 0; j < arr1[i].length; j++) {
                if (arr1[i][j] != arr2[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }
    

    public static int[][] rotate(int[][] arr) {
        int rows = arr.length;
        int cols = arr[0].length;
        int[][] rotatedArr = new int[cols][rows];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                rotatedArr[j][rows - i - 1] = arr[i][j];
            }
        }
        return rotatedArr;
    }
}

